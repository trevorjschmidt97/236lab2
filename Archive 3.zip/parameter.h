//
//  parameter.h
//  dataLog
//
//  Created by Trevor Schmidt on 10/2/19.
//  Copyright © 2019 Trevor Schmidt. All rights reserved.
//

#ifndef parameter_h
#define parameter_h

#include <stdio.h>

#endif /* parameter_h */
